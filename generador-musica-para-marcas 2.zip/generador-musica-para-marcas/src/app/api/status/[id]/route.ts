export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log('[Status API] 🔍 Checking status for:', params.id)

    const { data, error } = await supabaseAdmin
      .from('generations')
      .select(`
        id,
        suno_status,
        brand_name,
        genre,
        duration_seconds,
        moods,
        song_a_stream_url,
        song_a_image_url,
        song_a_lyrics,
        song_b_stream_url,
        song_b_image_url,
        song_b_lyrics,
        selected_song,
        regen_count,
        error_message,
        suno_task_id
      `)
      .eq('id', params.id)
      .single()

    if (error || !data) {
      console.error('[Status API] ❌ Not found:', params.id)
      return NextResponse.json({ error: 'No encontrado' }, { status: 404 })
    }

    console.log('[Status API] ✅ Status:', data.suno_status, '| Has streams:', !!data.song_a_stream_url)

    return NextResponse.json(data)

  } catch (err) {
    console.error('[/api/status] Error:', err)
    return NextResponse.json({ error: 'Error interno' }, { status: 500 })
  }
}
