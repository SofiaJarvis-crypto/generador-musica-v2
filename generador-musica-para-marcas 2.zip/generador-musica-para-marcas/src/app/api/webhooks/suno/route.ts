export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  console.log('[Webhook] 📨 Suno callback received')
  
  try {
    const generationId = req.nextUrl.searchParams.get('generationId')
    console.log('[Webhook] generationId:', generationId)

    if (!generationId) {
      console.error('[Webhook] ❌ No generationId')
      return NextResponse.json({ ok: true })
    }

    const body = await req.json()
    const { status, response } = body
    const sunoData = response?.sunoData || []

    console.log('[Webhook] Status:', status, '| Songs:', sunoData.length)

    // TEXT_SUCCESS: solo logging
    if (status === 'TEXT_SUCCESS') {
      console.log('[Webhook] TEXT_SUCCESS - no action')
      return NextResponse.json({ ok: true })
    }

    // FIRST_SUCCESS: primer track listo
    if (status === 'FIRST_SUCCESS' && sunoData.length > 0) {
      const songA = sunoData[0]
      const songB = sunoData[1]

      console.log('[Webhook] 🎵 FIRST_SUCCESS - updating database')

      const updateObj = {
        suno_status: 'stream_ready',
        song_a_id: songA.id,
        song_a_stream_url: songA.streamAudioUrl || null,
        song_a_image_url: songA.imageUrl || null,
        song_a_lyrics: songA.prompt || null,
      }

      if (songB) {
        updateObj.song_b_id = songB.id
        updateObj.song_b_stream_url = songB.streamAudioUrl || null
        updateObj.song_b_image_url = songB.imageUrl || null
        updateObj.song_b_lyrics = songB.prompt || null
      }

      const { data, error } = await supabaseAdmin
        .from('generations')
        .update(updateObj)
        .eq('id', generationId)
        .select()

      if (error) {
        console.error('[Webhook] ❌ FIRST_SUCCESS update failed:', error.message, error.code)
      } else {
        console.log('[Webhook] ✅ FIRST_SUCCESS updated')
      }

      return NextResponse.json({ ok: true })
    }

    // SUCCESS: ambos tracks listos
    if (status === 'SUCCESS' && sunoData.length >= 2) {
      const songA = sunoData[0]
      const songB = sunoData[1]

      console.log('[Webhook] 🎵 SUCCESS - updating database')

      const { data, error } = await supabaseAdmin
        .from('generations')
        .update({
          suno_status: 'complete',
          song_a_id: songA.id,
          song_a_stream_url: songA.streamAudioUrl || null,
          song_a_audio_url: songA.audioUrl || null,
          song_a_image_url: songA.imageUrl || null,
          song_a_lyrics: songA.prompt || null,
          song_b_id: songB.id,
          song_b_stream_url: songB.streamAudioUrl || null,
          song_b_audio_url: songB.audioUrl || null,
          song_b_image_url: songB.imageUrl || null,
          song_b_lyrics: songB.prompt || null,
        })
        .eq('id', generationId)
        .select()

      if (error) {
        console.error('[Webhook] ❌ SUCCESS update failed:', error.message, error.code)
      } else {
        console.log('[Webhook] ✅ SUCCESS updated')
      }

      return NextResponse.json({ ok: true })
    }

    // ERROR statuses
    if (['CREATE_TASK_FAILED', 'GENERATE_AUDIO_FAILED', 'SENSITIVE_WORD_ERROR'].includes(status)) {
      console.log('[Webhook] ⚠️ Suno error:', status)

      const { error } = await supabaseAdmin
        .from('generations')
        .update({
          suno_status: 'error',
          error_message: `Suno error: ${status}`,
        })
        .eq('id', generationId)

      if (error) {
        console.error('[Webhook] ❌ Error update failed:', error.message)
      }
    }

    console.log('[Webhook] ✅ Done')
    return NextResponse.json({ ok: true })

  } catch (err) {
    console.error('[Webhook] ❌ Exception:', err)
    return NextResponse.json({ ok: true })
  }
}
