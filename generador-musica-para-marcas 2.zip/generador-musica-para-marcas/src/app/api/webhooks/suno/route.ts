export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  console.log('[WEBHOOK] 📨 Suno callback received')
  
  try {
    const generationId = req.nextUrl.searchParams.get('generationId')
    console.log('[WEBHOOK] generationId:', generationId)

    if (!generationId) {
      console.log('[WEBHOOK] No generationId')
      return NextResponse.json({ ok: true })
    }

    const body = await req.json()
    const callbackType = body.callbackType
    const sunoData = body.data?.data || []

    console.log('[WEBHOOK] callbackType:', callbackType, '| songs:', sunoData.length)

    // TEXT: solo logging
    if (callbackType === 'text') {
      console.log('[WEBHOOK] TEXT - no action')
      return NextResponse.json({ ok: true })
    }

    // COMPLETE: ambos tracks listos
    if (callbackType === 'complete' && sunoData.length >= 2) {
      try {
        console.log('[WEBHOOK] COMPLETE - updating database')
        const songA = sunoData[0]
        const songB = sunoData[1]

        console.log('[WEBHOOK] Song A ID:', songA.id)
        console.log('[WEBHOOK] Song B ID:', songB.id)

        const { error } = await supabaseAdmin
          .from('generations')
          .update({
            suno_status: 'complete',
            song_a_id: songA.id,
            song_a_stream_url: songA.stream_audio_url || songA.source_stream_audio_url,
            song_a_audio_url: songA.audio_url || songA.source_audio_url,
            song_a_image_url: songA.image_url || songA.source_image_url,
            song_a_lyrics: songA.prompt,
            song_b_id: songB.id,
            song_b_stream_url: songB.stream_audio_url || songB.source_stream_audio_url,
            song_b_audio_url: songB.audio_url || songB.source_audio_url,
            song_b_image_url: songB.image_url || songB.source_image_url,
            song_b_lyrics: songB.prompt,
          })
          .eq('id', generationId)

        if (error) {
          console.error('[WEBHOOK] ❌ Update failed:', error.message)
        } else {
          console.log('[WEBHOOK] ✅ Updated successfully')
        }
      } catch (e) {
        console.error('[WEBHOOK] ❌ Exception:', e)
      }
      return NextResponse.json({ ok: true })
    }

    console.log('[WEBHOOK] Unknown callbackType:', callbackType)
    return NextResponse.json({ ok: true })

  } catch (err) {
    console.error('[WEBHOOK] ❌ Top error:', err)
    return NextResponse.json({ ok: true })
  }
}
