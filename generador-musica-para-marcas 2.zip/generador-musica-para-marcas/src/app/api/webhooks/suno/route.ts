export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  console.log('[WEBHOOK] 📨 Received')
  
  try {
    const generationId = req.nextUrl.searchParams.get('generationId')
    console.log('[WEBHOOK] generationId:', generationId)

    if (!generationId) {
      return NextResponse.json({ ok: true })
    }

    const body = await req.json()
    
    // Estructura correcta de Suno: body.data.callbackType y body.data.data
    const callbackType = body.data?.callbackType
    const songs = body.data?.data || []

    console.log('[WEBHOOK] callbackType:', callbackType, '| songs:', songs.length)

    // TEXT callback - solo logging
    if (callbackType === 'text') {
      console.log('[WEBHOOK] TEXT - skipping')
      return NextResponse.json({ ok: true })
    }

    // COMPLETE callback - actualizar BD
    if (callbackType === 'complete' && songs.length >= 2) {
      const songA = songs[0]
      const songB = songs[1]

      console.log('[WEBHOOK] COMPLETE - updating DB')
      console.log('[WEBHOOK] Song A:', songA.id)
      console.log('[WEBHOOK] Song B:', songB.id)

      const { error } = await supabaseAdmin
        .from('generations')
        .update({
          suno_status: 'complete',
          song_a_id: songA.id,
          song_a_stream_url: songA.stream_audio_url,
          song_a_audio_url: songA.audio_url,
          song_a_image_url: songA.image_url,
          song_a_lyrics: songA.prompt,
          song_b_id: songB.id,
          song_b_stream_url: songB.stream_audio_url,
          song_b_audio_url: songB.audio_url,
          song_b_image_url: songB.image_url,
          song_b_lyrics: songB.prompt,
        })
        .eq('id', generationId)

      if (error) {
        console.error('[WEBHOOK] ❌ DB ERROR:', JSON.stringify(error))
        return NextResponse.json({ ok: true })
      }

      console.log('[WEBHOOK] ✅ SUCCESS')
      return NextResponse.json({ ok: true })
    }

    console.log('[WEBHOOK] Unknown callbackType:', callbackType)
    return NextResponse.json({ ok: true })

  } catch (err) {
    console.error('[WEBHOOK] ❌ ERROR:', err)
    return NextResponse.json({ ok: true })
  }
}
