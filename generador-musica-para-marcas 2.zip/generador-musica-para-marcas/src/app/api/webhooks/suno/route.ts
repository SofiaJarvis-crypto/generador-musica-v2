export const dynamic = 'force-dynamic'

// src/app/api/webhooks/suno/route.ts
// POST — Suno nos llama aquí cuando la música está lista
// Tiene 3 etapas: text → first → complete
// Nosotros actualizamos Supabase en cada etapa

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  try {
    const generationId = req.nextUrl.searchParams.get('generationId')
    console.log('[Suno Webhook] 📨 generationId:', generationId)
    
    if (!generationId) {
      console.error('[Suno Webhook] ❌ Missing generationId')
      return NextResponse.json({ error: 'generationId requerido' }, { status: 400 })
    }

    const body = await req.json()
    const { status, response } = body
    const sunoData = response?.sunoData || []
    
    console.log('[Suno Webhook] 📨 Status:', status, '| Songs received:', sunoData.length)

    // ── Etapa: text (letra generada, audio aún no disponible) ──
    if (status === 'TEXT_SUCCESS') {
      console.log('[Suno Webhook] TEXT_SUCCESS → no DB update needed')
      return NextResponse.json({ ok: true })
    }

    // ── Etapa: first (primer track listo → streamAudioUrl disponible) ──
    if (status === 'FIRST_SUCCESS' && sunoData.length > 0) {
      try {
        const songA = sunoData[0]
        const songB = sunoData[1] || null

        console.log('[Suno Webhook] 🎵 FIRST_SUCCESS → updating to stream_ready')
        console.log('[Suno Webhook] Song A ID:', songA.id, '| Has stream URL:', !!songA.streamAudioUrl)

        const { data, error } = await supabaseAdmin
          .from('generations')
          .update({
            suno_status:       'stream_ready',
            song_a_id:         songA.id,
            song_a_stream_url: songA.streamAudioUrl,
            song_a_image_url:  songA.imageUrl || null,
            song_a_lyrics:     songA.prompt || null,
            ...(songB && {
              song_b_id:         songB.id,
              song_b_stream_url: songB.streamAudioUrl,
              song_b_image_url:  songB.imageUrl || null,
              song_b_lyrics:     songB.prompt || null,
            }),
          })
          .eq('id', generationId)

        if (error) {
          console.error('[Suno Webhook] ❌ FIRST_SUCCESS Update failed:', error.message)
        } else {
          console.log('[Suno Webhook] ✅ FIRST_SUCCESS Updated successfully')
        }
      } catch (err) {
        console.error('[Suno Webhook] ❌ FIRST_SUCCESS Exception:', err)
      }
      return NextResponse.json({ ok: true })
    }

    // ── Etapa: complete (ambos tracks listos con audioUrl descargable) ──
    if (status === 'SUCCESS' && sunoData.length >= 2) {
      try {
        const songA = sunoData[0]
        const songB = sunoData[1]

        console.log('[Suno Webhook] 🎵 SUCCESS → updating to complete')
        console.log('[Suno Webhook] Song A:', songA.id, '| Song B:', songB.id)

        const { data, error } = await supabaseAdmin
          .from('generations')
          .update({
            suno_status:       'complete',
            song_a_id:         songA.id,
            song_a_stream_url: songA.streamAudioUrl,
            song_a_audio_url:  songA.audioUrl,
            song_a_image_url:  songA.imageUrl || null,
            song_a_lyrics:     songA.prompt || null,
            song_b_id:         songB.id,
            song_b_stream_url: songB.streamAudioUrl,
            song_b_audio_url:  songB.audioUrl,
            song_b_image_url:  songB.imageUrl || null,
            song_b_lyrics:     songB.prompt || null,
          })
          .eq('id', generationId)

        if (error) {
          console.error('[Suno Webhook] ❌ SUCCESS Update failed:', error.message)
        } else {
          console.log('[Suno Webhook] ✅ SUCCESS Completed successfully')
        }
      } catch (err) {
        console.error('[Suno Webhook] ❌ SUCCESS Exception:', err)
      }
      return NextResponse.json({ ok: true })
    }

    // ── Error de Suno ──────────────────────────────────────
    if (['CREATE_TASK_FAILED', 'GENERATE_AUDIO_FAILED', 'SENSITIVE_WORD_ERROR'].includes(status)) {
      try {
        console.log('[Suno Webhook] ⚠️ Suno error status:', status)

        const { data, error } = await supabaseAdmin
          .from('generations')
          .update({
            suno_status:   'error',
            error_message: `Suno error: ${status}`,
          })
          .eq('id', generationId)

        if (error) {
          console.error('[Suno Webhook] ❌ Error update failed:', error.message)
        } else {
          console.log('[Suno Webhook] ✅ Marked as error')
        }
      } catch (err) {
        console.error('[Suno Webhook] ❌ Error handling Exception:', err)
      }
    }

    console.log('[Suno Webhook] ✅ Returning 200')
    return NextResponse.json({ ok: true })

  } catch (err) {
    console.error('[Suno Webhook] ❌ Top-level Error:', err)
    return NextResponse.json({ ok: true })
  }
}
