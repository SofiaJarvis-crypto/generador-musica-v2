export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(req: NextRequest) {
  const id = req.nextUrl.searchParams.get('id')
  
  if (!id) {
    return NextResponse.json({ error: 'Missing id param' }, { status: 400 })
  }

  try {
    // Test 1: Read
    console.log('[DEBUG] Reading generation:', id)
    const { data: readData, error: readError } = await supabaseAdmin
      .from('generations')
      .select('*')
      .eq('id', id)
      .single()

    // Test 2: Try to update
    console.log('[DEBUG] Attempting update...')
    const { data: updateData, error: updateError } = await supabaseAdmin
      .from('generations')
      .update({ suno_status: 'test_update' })
      .eq('id', id)
      .select()

    // Revert
    if (!updateError) {
      await supabaseAdmin
        .from('generations')
        .update({ suno_status: 'generating' })
        .eq('id', id)
    }

    return NextResponse.json({
      read: {
        success: !readError,
        error: readError?.message,
        data: readData,
      },
      update: {
        success: !updateError,
        error: updateError?.message,
        errorCode: updateError?.code,
        data: updateData,
      },
    })
  } catch (err: any) {
    return NextResponse.json({
      error: err.message,
      stack: err.stack,
    }, { status: 500 })
  }
}
